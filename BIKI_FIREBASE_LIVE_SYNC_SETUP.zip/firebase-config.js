// Firebase Console > Project settings > Your apps > Web app > SDK setup (Config).
// Replace ALL placeholder values. Firebase API key is a public client identifier, not a secret.
window.BIKI_FIREBASE_CONFIG = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  appId: "PASTE_APP_ID"
};
