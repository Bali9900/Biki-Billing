# BIKI ONLINE SERVICE CENTER — Firebase Live Sync

## Setup (আপনার Firebase Project-এ)

1. https://console.firebase.google.com এ নতুন Project তৈরি করুন।
2. Project Settings → Your apps → Web app যোগ করে Firebase config কপি করুন। `firebase-config.js`-এ চারটি placeholder বদলান। **এই config-এ কোনো private admin key/service account key বসাবেন না।**
3. Build → Authentication → Sign-in method → Email/Password ENABLE করুন। Users → Add user দিয়ে একটি শক্তিশালী password-সহ Owner Email account তৈরি করুন।
4. Authentication → Users থেকে Owner UID কপি করুন।
5. Build → Firestore Database → Create database (Production mode)। Rules tab-এ `firestore.rules` ফাইলের contents বসান এবং `YOUR_FIREBASE_AUTH_UID`-এর জায়গায় আসল UID বসিয়ে Publish করুন।
6. Authentication → Settings → Authorized domains-এ `bali9900.github.io` (অথবা আপনার নিজের host domain) যুক্ত করুন, যদি আগে থেকে না থাকে।
7. `index.html`, `firebase-sync.js`, `firebase-config.js` এবং `login-travel-background.jpg` (যদি থাকে) একই GitHub Pages repository root-এ upload করুন। `firestore.rules` GitHub-এ publish করার প্রয়োজন নেই।
8. GitHub Pages link খুলে Firebase Owner Email/Password দিয়ে login করুন। নতুন PC-তেও একই Email/Password ব্যবহার করুন।

## Old PC Data Migration

1. **পুরোনো PC/browser-এ প্রথমে** original website খুলে Business Pro → Daily Backup থেকে JSON backup download করুন। নতুন Cloud version দিয়ে replace করার **আগে** এটি করতে হবে।
2. Cloud website-এ Owner login করুন। `⬆ Import Old PC Data`-তে পুরোনো JSON backup নির্বাচন করুন। Confirm করলে আগের Cloud data overwrite হবে।
3. `⬇ Local Backup` দিয়ে migration-এর পরেও backup রাখুন। অন্য PC-তে reload করে পরীক্ষা করুন।
4. `biki_accounting_v1` document 900 KB ছাড়ালে Firestore write বন্ধ হবে। বড় ticket PDF/image থাকলে আলাদা Firebase Storage architecture দরকার; এই সংস্করণে বড় ফাইলের full cloud sync সমর্থিত নয়।

## Important limitations

- Firebase project configuration এবং Security Rules না বসানো পর্যন্ত website কাজ করবে না।
- Firebase Email/Password Authentication is authoritative; old `admin/1234`, browser-only PIN, browser-only staff passwords are disabled as valid cloud authentication. **Staff accounts must be rebuilt with Firebase Auth and role rules before staff access is enabled.**
- Existing Business Pro features retained. Firestore sync uses one document per storage key and last-write-wins. Simultaneous edits on two PCs to the same accounting record can overwrite one another. Avoid concurrent edits until a transaction-level Firestore data model is implemented.
- Single Firestore document has a 1 MiB maximum. App sync enforces a 900 KB value cap, so large original ticket PDF/base64 images cannot sync; local-only data isn't a cloud backup.
- Firebase billing/free quota depends on your Firebase plan. Enable billing alerts if appropriate.
- The old 'Cloud Backup URL/token' panel is an independent legacy feature, not Firebase sync. Use Firebase status at bottom-right instead.
- This build has not been connected to your live Firebase project or tested with your credentials; you must configure and test it before production.
- **Security note:** Existing code retains legacy admin-only actions checking a local password. They should be migrated to Firebase reauthentication before sensitive production use. Avoid real customer financial/identity documents until fully audited.
